var app = angular.module('app',['ngRoute']);
var user_login = sessionStorage.getItem('user_login') ? angular.fromJson(sessionStorage.getItem('user_login')) : [];
app.config(function($routeProvider){
	$routeProvider
	.when('/',{
		templateUrl:"./page/home.html"
	});
});

app.controller('mainCtrl', function($scope,$location,$http){
	

})